package bean;

public class Uploadbean {
	
	private String filename,filetype,filesize,filecontent,encrypt,decrypt,filekey,fileuser,fileowner,branch;
	private String filecateg,files,fileprior,filedescript;
	private String username,ipaddress,fkeyqr,listofip;
	
	public String getListofip() {
		return listofip;
	}
	public void setListofip(String listofip) {
		this.listofip = listofip;
	}
	public String getFkeyqr() {
		return fkeyqr;
	}
	public void setFkeyqr(String fkeyqr) {
		this.fkeyqr = fkeyqr;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public String getFilesize() {
		return filesize;
	}
	public void setFilesize(String filesize) {
		this.filesize = filesize;
	}
	public String getFilecontent() {
		return filecontent;
	}
	public void setFilecontent(String filecontent) {
		this.filecontent = filecontent;
	}
	public String getEncrypt() {
		return encrypt;
	}
	public void setEncrypt(String encrypt) {
		this.encrypt = encrypt;
	}
	public String getDecrypt() {
		return decrypt;
	}
	public void setDecrypt(String decrypt) {
		this.decrypt = decrypt;
	}
	public String getFilekey() {
		return filekey;
	}
	public void setFilekey(String filekey) {
		this.filekey = filekey;
	}
	public String getFileuser() {
		return fileuser;
	}
	public void setFileuser(String fileuser) {
		this.fileuser = fileuser;
	}
	public String getFileowner() {
		return fileowner;
	}
	public void setFileowner(String fileowner) {
		this.fileowner = fileowner;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getFilecateg() {
		return filecateg;
	}
	public void setFilecateg(String filecateg) {
		this.filecateg = filecateg;
	}
	public String getFiles() {
		return files;
	}
	public void setFiles(String files) {
		this.files = files;
	}
	public String getFileprior() {
		return fileprior;
	}
	public void setFileprior(String fileprior) {
		this.fileprior = fileprior;
	}
	public String getFiledescript() {
		return filedescript;
	}
	public void setFiledescript(String filedescript) {
		this.filedescript = filedescript;
	}
	
	

}
